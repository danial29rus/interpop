"""
:authors: danial29rus,CHERNOV,martishenya,KAHOROV

:Functions: 
    interpop.interpol()
    
    
    
"""
from .interpop import interpol

